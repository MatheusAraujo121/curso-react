import { useState } from 'react'
import './styles.css'
import Title from '../title'
import Button from '../button'

function App() {
  const [count, setCount] = useState(0)
  const [text, setText] = useState("Matheus Araujo")
  const [cargo, setCargo] = useState("dev")

  
  // const handleInput = (newText) => {
  //   setText(newText.value);
  //   if(newText.value.lenght > 3){

  //   }
  // }

  return (
    <>
      <Title name={text} paragrafo={count > 3} cargo={cargo}/>
      <div className="card">
        <button onClick={() => setCount((count) => count + 1)}>
          count is {count}
        </button>
        <br />
        <input 
          value={text} 
          onChange={(e) => setText(e.target.value)} 
          type="text"
        />
        <input 
          value={cargo} 
          onChange={(e) => setCargo(e.target.value)} 
          type="text"
        />
        <p>
          Edit <code>src/App.jsx</code> and save to test HMR
        </p>
        <Button count={count} setCount={setCount}/>
      </div>
    </>
  )
}

export default App
