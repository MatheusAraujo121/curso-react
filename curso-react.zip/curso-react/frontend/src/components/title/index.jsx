import reactLogo from '../../assets/react.svg'
import viteLogo from '/vite.svg'
import './styles.css'

function Title({ name, paragrafo, cargo }) {
  // const name = "Matheus Araujo";
  return (

    <>
      <div>
        <a href="https://vitejs.dev" target="_blank">
          <img src={viteLogo} className="logo " alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>
      <h1>{`${name} é um ${cargo}`}</h1>
        {paragrafo ? (
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam nam, voluptas exercitationem nostrum reprehenderit molestias? Deserunt impedit doloribus omnis blanditiis quas, dolore earum dolorem! Quae natus odit soluta dolorem sed.</p>
        ):(
          <p>não tem paragrafo</p>
        )}
    </>
  )
}

export default Title;
